# 🚀 Quick Start Guide

Get the Cultural Events Travel App running in 5 minutes!

## ⚡ Fast Setup

### Step 1: Install Dependencies (2 minutes)

**Option A: Using Command Line**
```bash
cd cultural-events-app
npm install
```

**Option B: Using Batch File (Windows)**
```bash
Double-click: install.bat
```

### Step 2: Start the Server (30 seconds)

**Option A: Using Command Line**
```bash
npm start
```

**Option B: Using Batch File (Windows)**
```bash
Double-click: start.bat
```

### Step 3: Open the App (10 seconds)

Open your browser and navigate to:
```
http://localhost:3001
```

## 🎯 First Time User Guide

### 1. Register an Account (1 minute)
```
1. Click "Register" button in the header
2. Fill in:
   - Name: Your Name
   - Email: your@email.com
   - Password: minimum 6 characters
3. Click "Register"
4. You're automatically logged in!
```

### 2. Explore Events (2 minutes)
```
1. Click on an interest card:
   🎨 Art | 🏛️ History | 🔬 Tech

2. Browse the events list
   - See beautiful images
   - Read descriptions
   - Check dates and prices

3. Click on any event for details
```

### 3. Book Your Trip (2 minutes)
```
1. On event details page:
   - Enter your city (e.g., "Bucharest")
   - Dates are pre-filled (you can change them)
   - Click "Find Flights & Hotels"

2. Select your options:
   - Choose a flight (click to select)
   - Switch to Hotels tab
   - Choose a hotel (click to select)

3. Review the summary:
   - Check total price
   - Click "Complete Booking"

4. Get confirmation:
   - Receive booking reference
   - Done! 🎉
```

## 🔧 Troubleshooting

### Server Won't Start?

**Problem**: Port 3001 is already in use

**Solution**: Change the port in `.env` file
```
PORT=3002
```

### Can't Install Dependencies?

**Problem**: npm install fails

**Solution**: Make sure Node.js is installed
```bash
node --version  # Should show v14 or higher
npm --version   # Should show v6 or higher
```

Download Node.js from: https://nodejs.org/

### Login Not Working?

**Problem**: Can't login after registration

**Solution**: Clear browser storage
```javascript
// Open browser console (F12) and run:
localStorage.clear()
// Then refresh the page
```

### Events Not Loading?

**Problem**: Events screen is empty

**Solution**: Check if server is running
```
Look for: "Server running on http://localhost:3001"
```

## 📱 Browser Compatibility

✅ **Recommended Browsers:**
- Chrome 90+
- Firefox 88+
- Edge 90+
- Safari 14+

## 🎨 Demo Data

The app comes with pre-loaded demo data:

### Art Events (3)
- Impressionism: Masters of Light (Paris)
- Contemporary Digital Art (London)
- Renaissance Masterpieces (Florence)

### History Events (3)
- Ancient Egypt: Pharaohs and Pyramids (London)
- World War II: Stories of Courage (London)
- Vikings: Life and Legends (Copenhagen)

### Tech Events (3)
- AI and Machine Learning: The Future (London)
- Space Exploration: Mars and Beyond (Washington DC)
- Robotics Revolution (Tokyo)

### Flights (3 per search)
- Air France: €350 (Direct)
- British Airways: €420 (Direct)
- Lufthansa: €280 (1 stop)

### Hotels (3 per search)
- Grand Hotel Central: €150/night
- Museum View Inn: €120/night
- City Center Suites: €200/night

## 🔐 Test Credentials

You can create any account, but here's a sample:

```
Email: demo@example.com
Password: demo123
Name: Demo User
```

## 📊 API Testing

### Using cURL

**Health Check:**
```bash
curl http://localhost:3001/api/health
```

**Get Art Events:**
```bash
curl http://localhost:3001/api/events/art
```

**Register User:**
```bash
curl -X POST http://localhost:3001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@example.com","password":"test123"}'
```

### Using Browser Console

```javascript
// Get events
fetch('http://localhost:3001/api/events/art')
  .then(r => r.json())
  .then(console.log);

// Register user
fetch('http://localhost:3001/api/auth/register', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'Test User',
    email: 'test@example.com',
    password: 'test123'
  })
})
  .then(r => r.json())
  .then(console.log);
```

## 🎯 Feature Checklist

Try all these features:

- [ ] Register a new account
- [ ] Login with credentials
- [ ] Select Art interest
- [ ] Browse art events
- [ ] View event details
- [ ] Search for flights and hotels
- [ ] Select a flight
- [ ] Select a hotel
- [ ] Review booking summary
- [ ] Complete a booking
- [ ] Logout
- [ ] Login again
- [ ] Try History interest
- [ ] Try Tech interest

## 📁 Project Structure

```
cultural-events-app/
├── public/
│   ├── index.html          # Main UI
│   └── app.js              # Frontend logic
├── server.js               # Backend API
├── package.json            # Dependencies
├── .env                    # Configuration
├── README.md              # Full documentation
├── QUICK-START.md         # This file
├── TECHNOLOGY-STACK.md    # Tech details
├── DEMO-GUIDE.md          # Presentation guide
├── install.bat            # Windows installer
└── start.bat              # Windows starter
```

## 🚀 Next Steps

After exploring the demo:

1. **Read Full Documentation**: `README.md`
2. **Understand Architecture**: `TECHNOLOGY-STACK.md`
3. **Prepare Presentation**: `DEMO-GUIDE.md`
4. **Explore Code**: 
   - Frontend: `public/app.js`
   - Backend: `server.js`
5. **Customize**: Modify colors, add features, etc.

## 💡 Tips

### For Development
```bash
# Use nodemon for auto-restart
npm run dev
```

### For Presentation
```bash
# Clear all data before demo
localStorage.clear()  # In browser console

# Use incognito mode for clean slate
```

### For Testing
```bash
# Test different scenarios:
1. Register → Browse → Book
2. Login → Different interest → Book
3. Multiple bookings
4. Error handling (wrong password, etc.)
```

## 🎓 Learning Resources

### Understanding the Code

**Frontend (public/app.js)**
- Lines 1-50: Configuration & State
- Lines 51-150: Authentication
- Lines 151-250: Screen Navigation
- Lines 251-350: Event Management
- Lines 351-449: Booking Flow

**Backend (server.js)**
- Lines 1-50: Setup & Security
- Lines 51-150: Mock Data
- Lines 151-250: Auth Routes
- Lines 251-350: Event Routes
- Lines 351-476: Booking Routes

### Key Concepts

1. **JWT Authentication**: Stateless auth with tokens
2. **RESTful API**: Standard HTTP methods
3. **Async/Await**: Modern JavaScript promises
4. **Security Headers**: Helmet.js protection
5. **Rate Limiting**: Prevent abuse

## 📞 Support

### Common Issues

**Issue**: "Cannot find module 'express'"
**Fix**: Run `npm install`

**Issue**: "Port 3001 already in use"
**Fix**: Change PORT in `.env` or kill the process

**Issue**: "CORS error"
**Fix**: Make sure you're accessing `localhost:3001`, not a different port

**Issue**: "Token expired"
**Fix**: Login again (tokens expire after 24 hours)

### Getting Help

1. Check `README.md` for detailed docs
2. Review `TECHNOLOGY-STACK.md` for architecture
3. Read error messages carefully
4. Check browser console (F12)
5. Check server terminal output

## ✅ Success Checklist

You've successfully set up the app when:

- ✅ Server starts without errors
- ✅ Browser opens to the app
- ✅ You can register an account
- ✅ You can browse events
- ✅ You can search flights/hotels
- ✅ You can complete a booking

## 🎉 Congratulations!

You now have a fully functional cultural events travel app running locally!

**What's Next?**
- Explore all features
- Read the full documentation
- Customize the design
- Add new features
- Prepare your presentation

---

**Need more help?** Check out the comprehensive `README.md` file!