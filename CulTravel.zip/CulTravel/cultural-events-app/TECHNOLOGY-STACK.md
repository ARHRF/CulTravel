# Technology Stack & Architecture Visualization

## 🏗️ System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                         CLIENT LAYER                             │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                    Web Browser                            │   │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐         │   │
│  │  │  HTML5     │  │   CSS3     │  │ JavaScript │         │   │
│  │  │  (UI)      │  │  (Styles)  │  │  (Logic)   │         │   │
│  │  └────────────┘  └────────────┘  └────────────┘         │   │
│  │         │               │               │                │   │
│  │         └───────────────┴───────────────┘                │   │
│  │                         │                                │   │
│  │                    Fetch API                             │   │
│  └─────────────────────────┼────────────────────────────────┘   │
└────────────────────────────┼─────────────────────────────────────┘
                             │
                    HTTP/HTTPS (REST)
                             │
┌────────────────────────────┼─────────────────────────────────────┐
│                    SECURITY LAYER                                │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌─────────┐ │   │
│  │  │ Helmet   │  │   CORS   │  │   Rate   │  │   JWT   │ │   │
│  │  │ Headers  │  │ Protection│  │ Limiting │  │  Auth   │ │   │
│  │  └──────────┘  └──────────┘  └──────────┘  └─────────┘ │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────────────┼─────────────────────────────────────┘
                             │
┌────────────────────────────┼─────────────────────────────────────┐
│                      API GATEWAY                                 │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                   Express.js Server                       │   │
│  │                      (Node.js)                            │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────────────┼─────────────────────────────────────┘
                             │
        ┌────────────────────┼────────────────────┐
        │                    │                    │
┌───────▼────────┐  ┌────────▼────────┐  ┌───────▼────────┐
│  Auth Service  │  │ Events Service  │  │ Booking Service│
│                │  │                 │  │                │
│ • Register     │  │ • Get Events    │  │ • Create       │
│ • Login        │  │ • Search        │  │ • Retrieve     │
│ • JWT Tokens   │  │ • Filter        │  │ • Manage       │
└────────────────┘  └─────────────────┘  └────────────────┘
        │                    │                    │
        │           ┌────────▼────────┐           │
        │           │ Flights Service │           │
        │           │                 │           │
        │           │ • Search Flights│           │
        │           │ • Mock Data     │           │
        │           └─────────────────┘           │
        │                    │                    │
        │           ┌────────▼────────┐           │
        │           │  Hotels Service │           │
        │           │                 │           │
        │           │ • Search Hotels │           │
        │           │ • Mock Data     │           │
        │           └─────────────────┘           │
        │                                         │
        └────────────────┬────────────────────────┘
                         │
┌────────────────────────▼─────────────────────────────────────────┐
│                      DATA LAYER                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │              In-Memory Storage (Demo)                     │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐              │   │
│  │  │  Users   │  │  Events  │  │ Bookings │              │   │
│  │  │  Array   │  │  Object  │  │  Array   │              │   │
│  │  └──────────┘  └──────────┘  └──────────┘              │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Production: MongoDB + Redis Cache                              │
└──────────────────────────────────────────────────────────────────┘
```

## 📚 Technology Stack Details

### Frontend Technologies

#### 1. HTML5
```
Purpose: Structure and semantic markup
Features Used:
  • Semantic elements (header, section, div)
  • Form elements with validation
  • Meta tags for responsive design
  • Accessibility attributes
```

#### 2. CSS3
```
Purpose: Styling and responsive design
Features Used:
  • CSS Grid & Flexbox layouts
  • CSS Variables (custom properties)
  • Animations & Transitions
  • Media queries (responsive)
  • Gradient backgrounds
  • Box shadows & border radius
```

#### 3. Vanilla JavaScript (ES6+)
```
Purpose: Client-side logic and interactivity
Features Used:
  • Async/Await for API calls
  • Fetch API for HTTP requests
  • LocalStorage for token persistence
  • Event listeners & DOM manipulation
  • Arrow functions
  • Template literals
  • Destructuring
  • Modules pattern
```

### Backend Technologies

#### 1. Node.js
```
Version: 14+
Purpose: JavaScript runtime environment
Benefits:
  • Non-blocking I/O
  • Event-driven architecture
  • NPM ecosystem
  • Cross-platform
```

#### 2. Express.js
```
Version: 4.18.2
Purpose: Web application framework
Features Used:
  • Routing
  • Middleware
  • Static file serving
  • JSON parsing
  • Error handling
```

### Security Technologies

#### 1. Helmet.js
```
Version: 7.1.0
Purpose: HTTP security headers
Headers Set:
  • Content-Security-Policy
  • X-Frame-Options: DENY
  • X-Content-Type-Options: nosniff
  • Strict-Transport-Security
  • X-XSS-Protection
```

#### 2. CORS
```
Version: 2.8.5
Purpose: Cross-Origin Resource Sharing
Configuration:
  • Origin: http://localhost:3000
  • Credentials: true
  • Methods: GET, POST, PUT, DELETE
```

#### 3. Express Rate Limit
```
Version: 7.1.5
Purpose: API rate limiting
Configuration:
  • Window: 15 minutes
  • Max requests: 100 per IP
  • Message: Custom error message
```

#### 4. bcryptjs
```
Version: 2.4.3
Purpose: Password hashing
Configuration:
  • Salt rounds: 10
  • Async hashing
  • Secure comparison
```

#### 5. JSON Web Tokens (JWT)
```
Version: 9.0.2
Purpose: Authentication tokens
Configuration:
  • Algorithm: HS256
  • Expiration: 24 hours
  • Secret: Environment variable
```

#### 6. dotenv
```
Version: 16.3.1
Purpose: Environment variable management
Usage:
  • API keys
  • JWT secrets
  • Port configuration
```

## 🔄 Data Flow Diagram

```
┌─────────────┐
│    User     │
└──────┬──────┘
       │
       │ 1. Opens App
       ▼
┌─────────────────┐
│  Interest       │
│  Selection      │◄─── 3 Cards: Art, History, Tech
└──────┬──────────┘
       │
       │ 2. Selects Interest
       ▼
┌─────────────────┐
│  GET /api/      │
│  events/:cat    │
└──────┬──────────┘
       │
       │ 3. Returns Events
       ▼
┌─────────────────┐
│  Events List    │◄─── Display cards with details
└──────┬──────────┘
       │
       │ 4. Selects Event
       ▼
┌─────────────────┐
│  Event Details  │◄─── Full information + images
└──────┬──────────┘
       │
       │ 5. Enters Location & Dates
       ▼
┌─────────────────┐     ┌─────────────────┐
│  POST /api/     │────▶│  POST /api/     │
│  flights/search │     │  hotels/search  │
└──────┬──────────┘     └────────┬────────┘
       │                         │
       │ 6. Returns Results      │
       ▼                         ▼
┌──────────────────────────────────┐
│     Search Results Screen        │
│  ┌────────────┐  ┌────────────┐ │
│  │  Flights   │  │   Hotels   │ │
│  └────────────┘  └────────────┘ │
└──────────────┬───────────────────┘
               │
               │ 7. Selects Flight & Hotel
               ▼
┌──────────────────────────────────┐
│      Booking Summary             │
│  • Flight: €350                  │
│  • Hotel: €450                   │
│  • Event: €18                    │
│  • Total: €818                   │
└──────────────┬───────────────────┘
               │
               │ 8. Complete Booking
               ▼
┌─────────────────┐
│  POST /api/     │
│  bookings       │◄─── Requires JWT Token
└──────┬──────────┘
       │
       │ 9. Returns Confirmation
       ▼
┌─────────────────┐
│  Booking        │
│  Confirmed      │◄─── Reference Number
└─────────────────┘
```

## 🔐 Authentication Flow

```
┌─────────────┐
│    User     │
└──────┬──────┘
       │
       │ 1. Clicks Register/Login
       ▼
┌─────────────────┐
│  Modal Dialog   │
│  (Form)         │
└──────┬──────────┘
       │
       │ 2. Submits Credentials
       ▼
┌─────────────────┐
│  POST /api/auth/│
│  register|login │
└──────┬──────────┘
       │
       │ 3. Validates Input
       ▼
┌─────────────────┐
│  bcrypt Hash    │◄─── Password Hashing
│  (Register only)│
└──────┬──────────┘
       │
       │ 4. Verify/Create User
       ▼
┌─────────────────┐
│  Generate JWT   │◄─── Sign with Secret
│  Token          │
└──────┬──────────┘
       │
       │ 5. Return Token + User Data
       ▼
┌─────────────────┐
│  Store in       │
│  LocalStorage   │
└──────┬──────────┘
       │
       │ 6. Update UI
       ▼
┌─────────────────┐
│  Show User      │
│  Avatar & Name  │
└─────────────────┘

Protected Requests:
┌─────────────────┐
│  API Request    │
└──────┬──────────┘
       │
       │ Include: Authorization: Bearer <token>
       ▼
┌─────────────────┐
│  Middleware     │
│  Verify Token   │
└──────┬──────────┘
       │
       ├─── Valid ──────▶ Process Request
       │
       └─── Invalid ────▶ 401 Unauthorized
```

## 📦 Package Dependencies

### Production Dependencies
```json
{
  "express": "^4.18.2",        // Web framework
  "cors": "^2.8.5",            // CORS middleware
  "helmet": "^7.1.0",          // Security headers
  "express-rate-limit": "^7.1.5", // Rate limiting
  "bcryptjs": "^2.4.3",        // Password hashing
  "jsonwebtoken": "^9.0.2",    // JWT authentication
  "dotenv": "^16.3.1"          // Environment variables
}
```

### Development Dependencies
```json
{
  "nodemon": "^3.0.2"          // Auto-restart server
}
```

## 🎨 UI Component Structure

```
App
├── Header
│   ├── Logo
│   └── Auth Section
│       ├── Login Button
│       ├── Register Button
│       └── User Info
│           ├── Avatar
│           ├── Name
│           └── Logout Button
│
├── Screens
│   ├── Interest Selection
│   │   └── Interest Cards (3)
│   │       ├── Icon
│   │       ├── Title
│   │       └── Description
│   │
│   ├── Events List
│   │   ├── Header (Back Button + Title)
│   │   └── Events Grid
│   │       └── Event Cards
│   │           ├── Image
│   │           ├── Title
│   │           ├── Museum
│   │           ├── Location
│   │           ├── Dates
│   │           └── Price
│   │
│   ├── Event Details
│   │   ├── Back Button
│   │   ├── Hero Image
│   │   ├── Event Info
│   │   └── Location Input
│   │       ├── Departure City
│   │       ├── Dates
│   │       └── Search Button
│   │
│   └── Search Results
│       ├── Back Button
│       ├── Tabs (Flights/Hotels)
│       ├── Results Grid
│       │   └── Result Cards
│       └── Booking Summary
│           ├── Selected Items
│           ├── Total Price
│           └── Book Button
│
└── Modals
    ├── Login Modal
    │   └── Login Form
    └── Register Modal
        └── Register Form
```

## 🔧 API Endpoint Structure

```
/api
├── /health                    [GET]    Public
├── /auth
│   ├── /register             [POST]   Public
│   └── /login                [POST]   Public
├── /events
│   ├── /:category            [GET]    Public
│   └── /detail/:id           [GET]    Public
├── /flights
│   └── /search               [POST]   Protected
├── /hotels
│   └── /search               [POST]   Protected
└── /bookings
    ├── /                     [POST]   Protected
    ├── /                     [GET]    Protected
    └── /:id                  [GET]    Protected
```

## 🚀 Performance Optimizations

### Frontend
- Minimal dependencies (vanilla JS)
- CSS animations (GPU accelerated)
- Lazy loading of images
- Debounced search inputs
- LocalStorage for auth persistence

### Backend
- In-memory caching (demo)
- Rate limiting to prevent abuse
- Efficient routing
- Async/await for non-blocking I/O
- Compression ready (gzip)

## 🔒 Security Measures Summary

| Layer | Technology | Purpose |
|-------|-----------|---------|
| Transport | HTTPS Ready | Encrypted communication |
| Headers | Helmet.js | Security headers |
| CORS | cors | Origin validation |
| Rate Limit | express-rate-limit | DDoS protection |
| Authentication | JWT | Stateless auth |
| Password | bcryptjs | Secure hashing |
| Input | Validation | Prevent injection |
| Tokens | Environment vars | Secret management |

## 📊 Scalability Path

### Current (Demo)
```
Single Server
├── Express.js
├── In-memory storage
└── Mock data
```

### Production Ready
```
Load Balancer
├── Server 1 (Express)
├── Server 2 (Express)
└── Server N (Express)
    ├── MongoDB (Database)
    ├── Redis (Cache)
    └── External APIs
        ├── Amadeus (Flights)
        ├── Booking.com (Hotels)
        └── Stripe (Payments)
```

## 🎯 Technology Choices Rationale

### Why Node.js + Express?
- JavaScript full-stack (same language)
- Large ecosystem (npm)
- Fast development
- Excellent for I/O operations
- Easy to scale

### Why Vanilla JavaScript?
- No build process needed
- Faster load times
- Easier to understand
- No framework lock-in
- Perfect for demo/prototype

### Why JWT?
- Stateless authentication
- Scalable (no server sessions)
- Mobile-friendly
- Industry standard
- Easy to implement

### Why In-Memory Storage?
- Demo purposes
- Fast development
- No database setup needed
- Easy to understand
- Production: MongoDB recommended

---

*This technology stack provides a solid foundation for a production-ready application with proper security measures and scalability options.*