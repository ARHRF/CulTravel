@echo off
echo Installing dependencies...
npm install
echo.
echo Installation complete!
echo.
echo To start the server, run: npm start
pause

@REM Made with Bob
