const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

// Security Middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

app.use(cors({
  origin: 'http://localhost:3001',
  credentials: true
}));

app.use(express.json());
app.use(express.static('public'));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.'
});

app.use('/api/', limiter);

// Mock Database
const users = [];
const bookings = [];

// Mock Data
const mockEvents = {
  art: [
    {
      id: 'art-1',
      title: 'Impressionism: Masters of Light',
      museum: 'Musée d\'Orsay',
      location: { city: 'Paris', country: 'France', lat: 48.8606, lng: 2.3266 },
      dates: { start: '2026-06-01', end: '2026-08-31' },
      description: 'Explore the revolutionary art movement that changed painting forever. Featuring works by Monet, Renoir, and Degas.',
      image: 'https://images.unsplash.com/photo-1499781350541-7783f6c6a0c8?w=800',
      price: 18,
      category: 'art'
    },
    {
      id: 'art-2',
      title: 'Contemporary Digital Art Exhibition',
      museum: 'Tate Modern',
      location: { city: 'London', country: 'UK', lat: 51.5076, lng: -0.0994 },
      dates: { start: '2026-06-15', end: '2026-09-15' },
      description: 'Experience cutting-edge digital installations and interactive art pieces from leading contemporary artists.',
      image: 'https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?w=800',
      price: 22,
      category: 'art'
    },
    {
      id: 'art-3',
      title: 'Renaissance Masterpieces',
      museum: 'Uffizi Gallery',
      location: { city: 'Florence', country: 'Italy', lat: 43.7686, lng: 11.2558 },
      dates: { start: '2026-06-01', end: '2026-07-31' },
      description: 'A rare collection of Renaissance paintings including works by Botticelli, Leonardo da Vinci, and Michelangelo.',
      image: 'https://images.unsplash.com/photo-1580060839134-75a5edca2e99?w=800',
      price: 20,
      category: 'art'
    }
  ],
  history: [
    {
      id: 'hist-1',
      title: 'Ancient Egypt: Pharaohs and Pyramids',
      museum: 'British Museum',
      location: { city: 'London', country: 'UK', lat: 51.5194, lng: -0.1270 },
      dates: { start: '2026-06-10', end: '2026-09-30' },
      description: 'Journey through 3,000 years of Egyptian civilization with artifacts from the age of the Pharaohs.',
      image: 'https://images.unsplash.com/photo-1503177119275-0aa32b3a9368?w=800',
      price: 15,
      category: 'history'
    },
    {
      id: 'hist-2',
      title: 'World War II: Stories of Courage',
      museum: 'Imperial War Museum',
      location: { city: 'London', country: 'UK', lat: 51.4958, lng: -0.1088 },
      dates: { start: '2026-06-05', end: '2026-08-15' },
      description: 'Personal stories and artifacts from WWII, exploring the human experience during wartime.',
      image: 'https://images.unsplash.com/photo-1461360228754-6e81c478b882?w=800',
      price: 12,
      category: 'history'
    },
    {
      id: 'hist-3',
      title: 'Vikings: Life and Legends',
      museum: 'National Museum of Denmark',
      location: { city: 'Copenhagen', country: 'Denmark', lat: 55.6761, lng: 12.5683 },
      dates: { start: '2026-06-20', end: '2026-09-20' },
      description: 'Discover the true story of the Vikings through authentic artifacts, weapons, and daily life objects.',
      image: 'https://images.unsplash.com/photo-1604357209793-fca5dca89f97?w=800',
      price: 16,
      category: 'history'
    }
  ],
  tech: [
    {
      id: 'tech-1',
      title: 'AI and Machine Learning: The Future',
      museum: 'Science Museum',
      location: { city: 'London', country: 'UK', lat: 51.4978, lng: -0.1745 },
      dates: { start: '2026-06-01', end: '2026-08-31' },
      description: 'Interactive exhibition exploring artificial intelligence, machine learning, and their impact on society.',
      image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800',
      price: 18,
      category: 'tech'
    },
    {
      id: 'tech-2',
      title: 'Space Exploration: Mars and Beyond',
      museum: 'Smithsonian Air and Space Museum',
      location: { city: 'Washington DC', country: 'USA', lat: 38.8882, lng: -77.0199 },
      dates: { start: '2026-06-15', end: '2026-09-30' },
      description: 'Experience the latest in space technology and Mars exploration missions with real spacecraft and simulations.',
      image: 'https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=800',
      price: 25,
      category: 'tech'
    },
    {
      id: 'tech-3',
      title: 'Robotics Revolution',
      museum: 'Miraikan Museum',
      location: { city: 'Tokyo', country: 'Japan', lat: 35.6195, lng: 139.7766 },
      dates: { start: '2026-06-10', end: '2026-08-20' },
      description: 'Hands-on experience with cutting-edge robotics, from industrial automation to humanoid companions.',
      image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800',
      price: 20,
      category: 'tech'
    }
  ]
};

const mockFlights = [
  {
    id: 'flight-1',
    airline: 'Air France',
    price: 350,
    departure: '10:00',
    arrival: '12:30',
    duration: '2h 30m',
    stops: 0
  },
  {
    id: 'flight-2',
    airline: 'British Airways',
    price: 420,
    departure: '14:00',
    arrival: '16:15',
    duration: '2h 15m',
    stops: 0
  },
  {
    id: 'flight-3',
    airline: 'Lufthansa',
    price: 280,
    departure: '08:00',
    arrival: '11:45',
    duration: '3h 45m',
    stops: 1
  }
];

const mockHotels = [
  {
    id: 'hotel-1',
    name: 'Grand Hotel Central',
    rating: 4.5,
    price: 150,
    distance: '0.5 km',
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400',
    amenities: ['WiFi', 'Breakfast', 'Parking']
  },
  {
    id: 'hotel-2',
    name: 'Museum View Inn',
    rating: 4.2,
    price: 120,
    distance: '0.8 km',
    image: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400',
    amenities: ['WiFi', 'Restaurant', 'Gym']
  },
  {
    id: 'hotel-3',
    name: 'City Center Suites',
    rating: 4.7,
    price: 200,
    distance: '1.2 km',
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=400',
    amenities: ['WiFi', 'Spa', 'Pool', 'Breakfast']
  }
];

// Authentication Middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Input validation middleware
const validateInput = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }
    next();
  };
};

// API Routes

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Auth Routes
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;

    // Validation
    if (!email || !password || !name) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    // Check if user exists
    if (users.find(u => u.email === email)) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const user = {
      id: Date.now().toString(),
      email,
      name,
      password: hashedPassword,
      createdAt: new Date().toISOString()
    };

    users.push(user);

    // Generate token
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '24h' });

    res.status(201).json({
      message: 'User registered successfully',
      token,
      user: { id: user.id, email: user.email, name: user.name }
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validation
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    // Find user
    const user = users.find(u => u.email === email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Check password
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Generate token
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '24h' });

    res.json({
      message: 'Login successful',
      token,
      user: { id: user.id, email: user.email, name: user.name }
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Events Routes
app.get('/api/events/:category', (req, res) => {
  const { category } = req.params;
  const events = mockEvents[category] || [];
  res.json({ events });
});

app.get('/api/events/detail/:id', (req, res) => {
  const { id } = req.params;
  const allEvents = [...mockEvents.art, ...mockEvents.history, ...mockEvents.tech];
  const event = allEvents.find(e => e.id === id);
  
  if (!event) {
    return res.status(404).json({ error: 'Event not found' });
  }
  
  res.json({ event });
});

// Flights Routes
app.post('/api/flights/search', (req, res) => {
  const { origin, destination, departureDate, returnDate } = req.body;
  
  // Simulate API delay
  setTimeout(() => {
    res.json({ 
      flights: mockFlights,
      searchParams: { origin, destination, departureDate, returnDate }
    });
  }, 500);
});

// Hotels Routes
app.post('/api/hotels/search', (req, res) => {
  const { location, checkIn, checkOut, guests } = req.body;
  
  // Simulate API delay
  setTimeout(() => {
    res.json({ 
      hotels: mockHotels,
      searchParams: { location, checkIn, checkOut, guests }
    });
  }, 500);
});

// Bookings Routes (Protected)
app.post('/api/bookings', authenticateToken, (req, res) => {
  try {
    const { eventId, flightId, hotelId, totalAmount } = req.body;

    if (!eventId || !flightId || !hotelId || !totalAmount) {
      return res.status(400).json({ error: 'Missing required booking information' });
    }

    const booking = {
      id: Date.now().toString(),
      userId: req.user.id,
      eventId,
      flightId,
      hotelId,
      totalAmount,
      status: 'confirmed',
      bookingReference: `BK${Date.now()}`,
      createdAt: new Date().toISOString()
    };

    bookings.push(booking);

    res.status(201).json({
      message: 'Booking created successfully',
      booking
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/bookings', authenticateToken, (req, res) => {
  const userBookings = bookings.filter(b => b.userId === req.user.id);
  res.json({ bookings: userBookings });
});

app.get('/api/bookings/:id', authenticateToken, (req, res) => {
  const booking = bookings.find(b => b.id === req.params.id && b.userId === req.user.id);
  
  if (!booking) {
    return res.status(404).json({ error: 'Booking not found' });
  }
  
  res.json({ booking });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`📊 API available at http://localhost:${PORT}/api`);
  console.log(`🔒 Security features enabled: Helmet, CORS, Rate Limiting`);
});

// Made with Bob
