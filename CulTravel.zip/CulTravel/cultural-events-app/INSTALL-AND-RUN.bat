@echo off
echo ========================================
echo Cultural Events Travel App
echo Installation and Startup
echo ========================================
echo.

REM Check if we're in the right directory
if not exist "package.json" (
    echo ERROR: package.json not found!
    echo.
    echo You must run this file from the cultural-events-app folder.
    echo.
    echo Current directory: %CD%
    echo Expected directory: Desktop\cultural-events-app
    echo.
    pause
    exit /b 1
)

echo Step 1: Installing dependencies...
echo This may take a few minutes on first run.
echo.
call npm install

if errorlevel 1 (
    echo.
    echo ERROR: npm install failed!
    echo.
    echo Make sure Node.js is installed.
    echo Download from: https://nodejs.org/
    echo.
    pause
    exit /b 1
)

echo.
echo ========================================
echo Installation complete!
echo ========================================
echo.
echo Step 2: Starting the server...
echo.
echo The app will be available at:
echo http://localhost:3001
echo.
echo Press Ctrl+C to stop the server
echo ========================================
echo.

REM Start the server
node server.js

pause

@REM Made with Bob
