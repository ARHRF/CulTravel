# 🔄 Workflow Diagrams & Visual Documentation

## 📊 Complete Application Workflow

### High-Level User Journey

```mermaid
graph TB
    Start([User Opens App]) --> Auth{Authenticated?}
    Auth -->|No| Login[Login/Register]
    Auth -->|Yes| Interest[Select Interest]
    Login --> Interest
    
    Interest --> Events[Browse Events]
    Events --> Detail[View Event Details]
    Detail --> Location[Enter Location & Dates]
    Location --> Search[Search Travel Options]
    Search --> Select[Select Flight & Hotel]
    Select --> Review[Review Booking]
    Review --> Book[Complete Booking]
    Book --> Confirm([Confirmation])
    
    style Start fill:#e1f5ff
    style Interest fill:#fff4e1
    style Events fill:#ffe1f5
    style Search fill:#e1ffe1
    style Book fill:#ffe1e1
    style Confirm fill:#e1ffe1
```

---

## 🎨 Interest Selection Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    LANDING PAGE                              │
│                                                              │
│              Discover Cultural Events                        │
│     Choose your interest to explore exhibitions              │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │              │  │              │  │              │      │
│  │      🎨      │  │      🏛️      │  │      🔬      │      │
│  │              │  │              │  │              │      │
│  │     Art      │  │   History    │  │     Tech     │      │
│  │              │  │              │  │              │      │
│  │   Explore    │  │   Discover   │  │  Experience  │      │
│  │  paintings,  │  │   ancient    │  │  cutting-    │      │
│  │  sculptures  │  │civilizations │  │    edge      │      │
│  │              │  │              │  │ technology   │      │
│  │              │  │              │  │              │      │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘      │
│         │                 │                 │              │
└─────────┼─────────────────┼─────────────────┼──────────────┘
          │                 │                 │
          ▼                 ▼                 ▼
    ┌──────────┐      ┌──────────┐      ┌──────────┐
    │   Art    │      │ History  │      │   Tech   │
    │  Events  │      │  Events  │      │  Events  │
    └──────────┘      └──────────┘      └──────────┘
```

---

## 📅 Event Discovery Flow

```
┌─────────────────────────────────────────────────────────────┐
│  [← Back]  🎨 Art Exhibitions                               │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
        ┌─────────────────────────────────────┐
        │   GET /api/events/art               │
        │   Returns: Array of events          │
        └─────────────────┬───────────────────┘
                          │
                          ▼
        ┌─────────────────────────────────────┐
        │   Render Event Cards                │
        │   • Image                           │
        │   • Title                           │
        │   • Museum                          │
        │   • Location                        │
        │   • Dates                           │
        │   • Price                           │
        └─────────────────┬───────────────────┘
                          │
                          ▼
                    User Clicks Event
                          │
                          ▼
        ┌─────────────────────────────────────┐
        │   Navigate to Event Details         │
        └─────────────────────────────────────┘
```

---

## 🔐 Authentication Flow

### Registration Process

```
┌──────────────┐
│ User clicks  │
│  "Register"  │
└──────┬───────┘
       │
       ▼
┌──────────────────────────────────────┐
│  Registration Modal Opens            │
│  ┌────────────────────────────────┐  │
│  │ Name:     [____________]       │  │
│  │ Email:    [____________]       │  │
│  │ Password: [____________]       │  │
│  │                                │  │
│  │        [Register]              │  │
│  └────────────────────────────────┘  │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  POST /api/auth/register             │
│  Body: { name, email, password }     │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Server Validation                   │
│  • Check required fields             │
│  • Validate email format             │
│  • Check password length (min 6)     │
│  • Check if user exists              │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Hash Password                       │
│  bcrypt.hash(password, 10)           │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Create User Object                  │
│  { id, email, name, hashedPassword } │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Generate JWT Token                  │
│  jwt.sign({ id, email }, secret)     │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Return Response                     │
│  { token, user: { id, email, name }}│
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Client Stores Token                 │
│  localStorage.setItem('token', ...)  │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Update UI                           │
│  • Hide auth buttons                 │
│  • Show user avatar & name           │
│  • Show logout button                │
└──────────────────────────────────────┘
```

### Login Process

```
User Enters Credentials
         │
         ▼
POST /api/auth/login
         │
         ▼
Find User by Email
         │
         ├─── Not Found ──→ 401 Error
         │
         ▼
Compare Password (bcrypt)
         │
         ├─── Invalid ──→ 401 Error
         │
         ▼
Generate JWT Token
         │
         ▼
Return Token + User Data
         │
         ▼
Store in localStorage
         │
         ▼
Update UI (Show User Info)
```

### Protected Request Flow

```
┌──────────────────────────────────────┐
│  User Makes Protected Request        │
│  (e.g., Search Flights)              │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Get Token from localStorage         │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Add to Request Headers              │
│  Authorization: Bearer <token>       │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Server: authenticateToken()         │
│  Middleware                          │
└──────────────┬───────────────────────┘
               │
               ├─── No Token ──→ 401 Unauthorized
               │
               ▼
┌──────────────────────────────────────┐
│  Verify Token                        │
│  jwt.verify(token, secret)           │
└──────────────┬───────────────────────┘
               │
               ├─── Invalid ──→ 403 Forbidden
               │
               ▼
┌──────────────────────────────────────┐
│  Token Valid                         │
│  Attach user to request              │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Process Request                     │
│  Return Response                     │
└──────────────────────────────────────┘
```

---

## ✈️ Travel Search Flow

```
┌─────────────────────────────────────────────────────────────┐
│  EVENT DETAILS PAGE                                         │
│                                                             │
│  Plan Your Trip                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ Departure City: [Bucharest                        ]   │ │
│  │ Departure Date: [2026-06-08                       ]   │ │
│  │ Return Date:    [2026-06-11                       ]   │ │
│  │                                                       │ │
│  │              [Find Flights & Hotels]                  │ │
│  └───────────────────────────────────────────────────────┘ │
└─────────────────────────────┬───────────────────────────────┘
                              │
                              ▼
                    Check Authentication
                              │
                ┌─────────────┴─────────────┐
                │                           │
           Not Logged In              Logged In
                │                           │
                ▼                           ▼
        Show Login Modal          Navigate to Search
                                          │
                                          ▼
                        ┌─────────────────────────────────┐
                        │  Parallel API Calls             │
                        │  ┌─────────────┐ ┌────────────┐│
                        │  │POST /api/   │ │POST /api/  ││
                        │  │flights/     │ │hotels/     ││
                        │  │search       │ │search      ││
                        │  └──────┬──────┘ └─────┬──────┘│
                        └─────────┼──────────────┼───────┘
                                  │              │
                                  ▼              ▼
                        ┌─────────────┐  ┌─────────────┐
                        │   Flights   │  │   Hotels    │
                        │   Results   │  │   Results   │
                        └──────┬──────┘  └─────┬───────┘
                               │                │
                               └────────┬───────┘
                                        │
                                        ▼
                        ┌─────────────────────────────────┐
                        │  SEARCH RESULTS SCREEN          │
                        │  ┌────────────┐ ┌────────────┐  │
                        │  │  Flights   │ │   Hotels   │  │
                        │  │    Tab     │ │    Tab     │  │
                        │  └────────────┘ └────────────┘  │
                        │                                 │
                        │  Booking Summary                │
                        │  • Selected Flight: €350        │
                        │  • Selected Hotel: €450         │
                        │  • Event Ticket: €18            │
                        │  • Total: €818                  │
                        │                                 │
                        │  [Complete Booking]             │
                        └─────────────────────────────────┘
```

---

## 🏨 Selection & Booking Flow

```
┌─────────────────────────────────────────────────────────────┐
│  SEARCH RESULTS                                             │
│                                                             │
│  [✈️ Flights Tab]  [🏨 Hotels Tab]                          │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ ✈️ Air France                              €350       │ │
│  │ 10:00 → 12:30 | 2h 30m | Direct                      │ │
│  └───────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ ✈️ British Airways                         €420       │ │
│  │ 14:00 → 16:15 | 2h 15m | Direct                      │ │
│  └───────────────────────────────────────────────────────┘ │
└─────────────────────────────┬───────────────────────────────┘
                              │
                    User Clicks Flight Card
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Highlight Card      │
                    │ Store Selection     │
                    │ Update Summary      │
                    └──────────┬──────────┘
                               │
                               ▼
                    User Switches to Hotels Tab
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│  [✈️ Flights Tab]  [🏨 Hotels Tab]                          │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ [Image] 🏨 Grand Hotel Central            €450        │ │
│  │         ⭐ 4.5 | 📍 0.5 km                            │ │
│  │         WiFi • Breakfast • Parking                    │ │
│  └───────────────────────────────────────────────────────┘ │
└─────────────────────────────┬───────────────────────────────┘
                              │
                    User Clicks Hotel Card
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Highlight Card      │
                    │ Store Selection     │
                    │ Calculate Nights    │
                    │ Update Summary      │
                    └──────────┬──────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│  BOOKING SUMMARY (Updated)                                  │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ Selected Flight:    Air France - €350                 │ │
│  │ Selected Hotel:     Grand Hotel Central - €450        │ │
│  │ Event Ticket:       €18                               │ │
│  │ ─────────────────────────────────────────────────     │ │
│  │ Total:              €818                              │ │
│  │                                                       │ │
│  │              [Complete Booking]                       │ │
│  └───────────────────────────────────────────────────────┘ │
└─────────────────────────────┬───────────────────────────────┘
                              │
                    User Clicks Complete Booking
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Validate Selections │
                    │ • Flight selected?  │
                    │ • Hotel selected?   │
                    └──────────┬──────────┘
                               │
                               ▼
                    POST /api/bookings
                    {
                      eventId, flightId,
                      hotelId, totalAmount
                    }
                               │
                               ▼
                    ┌─────────────────────┐
                    │ Create Booking      │
                    │ Generate Reference  │
                    │ Store in Database   │
                    └──────────┬──────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │ Return Confirmation │
                    │ BK1714582800123     │
                    └──────────┬──────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │ Show Success Alert  │
                    │ Reset Selections    │
                    │ Navigate to Home    │
                    └─────────────────────┘
```

---

## 🔒 Security Layer Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                      CLIENT REQUEST                          │
│                    (Browser/Mobile)                          │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                    TRANSPORT LAYER                           │
│                   HTTPS/TLS Encryption                       │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                   SECURITY HEADERS                           │
│                     (Helmet.js)                              │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ • Content-Security-Policy                             │  │
│  │ • X-Frame-Options: DENY                               │  │
│  │ • X-Content-Type-Options: nosniff                     │  │
│  │ • Strict-Transport-Security                           │  │
│  │ • X-XSS-Protection                                    │  │
│  └───────────────────────────────────────────────────────┘  │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                      CORS CHECK                              │
│              Origin Validation                               │
│         Allowed: http://localhost:3000                       │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                    RATE LIMITING                             │
│           100 requests per 15 minutes                        │
│                  per IP address                              │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                  INPUT VALIDATION                            │
│              Server-side Checks                              │
│  • Required fields present                                   │
│  • Data types correct                                        │
│  • Length constraints                                        │
│  • Format validation                                         │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
                    ┌──────────────────┐
                    │ Protected Route? │
                    └────────┬─────────┘
                             │
                    ┌────────┴────────┐
                    │                 │
                   Yes               No
                    │                 │
                    ▼                 ▼
        ┌───────────────────┐   ┌──────────────┐
        │ JWT Verification  │   │   Process    │
        │                   │   │   Request    │
        │ • Token present?  │   └──────────────┘
        │ • Token valid?    │
        │ • Not expired?    │
        └────────┬──────────┘
                 │
        ┌────────┴────────┐
        │                 │
      Valid           Invalid
        │                 │
        ▼                 ▼
┌──────────────┐   ┌──────────────┐
│   Process    │   │ 401/403      │
│   Request    │   │ Error        │
└──────────────┘   └──────────────┘
```

---

## 📊 Data Flow Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      FRONTEND                                │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  User Interface (HTML/CSS/JS)                          │ │
│  │  • Interest Selection                                  │ │
│  │  • Events List                                         │ │
│  │  • Event Details                                       │ │
│  │  • Search Results                                      │ │
│  │  • Booking Flow                                        │ │
│  └────────────────────┬───────────────────────────────────┘ │
└───────────────────────┼──────────────────────────────────────┘
                        │
                        │ HTTP/HTTPS
                        │ Fetch API
                        │
┌───────────────────────▼──────────────────────────────────────┐
│                   API GATEWAY                                │
│                  (Express.js)                                │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Route Handlers                                        │ │
│  │  • /api/auth/*                                         │ │
│  │  • /api/events/*                                       │ │
│  │  • /api/flights/*                                      │ │
│  │  • /api/hotels/*                                       │ │
│  │  • /api/bookings/*                                     │ │
│  └────────────────────┬───────────────────────────────────┘ │
└───────────────────────┼──────────────────────────────────────┘
                        │
        ┌───────────────┼───────────────┐
        │               │               │
        ▼               ▼               ▼
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│    Auth      │ │   Events     │ │   Booking    │
│   Service    │ │   Service    │ │   Service    │
│              │ │              │ │              │
│ • Register   │ │ • Get Events │ │ • Create     │
│ • Login      │ │ • Search     │ │ • Retrieve   │
│ • Verify     │ │ • Filter     │ │ • Update     │
└──────┬───────┘ └──────┬───────┘ └──────┬───────┘
       │                │                │
       │                │                │
       ▼                ▼                ▼
┌─────────────────────────────────────────────────────────────┐
│                    DATA LAYER                                │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  In-Memory Storage (Demo)                              │ │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐            │ │
│  │  │  users[] │  │ events{} │  │bookings[]│            │ │
│  │  └──────────┘  └──────────┘  └──────────┘            │ │
│  │                                                        │ │
│  │  Production: MongoDB + Redis                          │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 State Management Flow

```
┌─────────────────────────────────────────────────────────────┐
│                   APPLICATION STATE                          │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Global State Variables                                │ │
│  │  • currentUser: null | UserObject                      │ │
│  │  • currentInterest: null | 'art'|'history'|'tech'      │ │
│  │  • currentEvent: null | EventObject                    │ │
│  │  • selectedFlight: null | FlightObject                 │ │
│  │  • selectedHotel: null | HotelObject                   │ │
│  │  • events: []                                          │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                        │
        ┌───────────────┼───────────────┐
        │               │               │
        ▼               ▼               ▼
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│ LocalStorage │ │   Memory     │ │  API Calls   │
│              │ │              │ │              │
│ • token      │ │ • events[]   │ │ • Fetch data │
│ • user       │ │ • selections │ │ • Update     │
└──────────────┘ └──────────────┘ └──────────────┘

State Updates:
1. User Action → Update State
2. State Change → Update UI
3. API Response → Update State → Update UI
4. Logout → Clear State → Update UI
```

---

## 🔄 Complete Booking Lifecycle

```
1. USER DISCOVERY
   └─→ Select Interest
       └─→ Browse Events
           └─→ View Event Details

2. TRAVEL PLANNING
   └─→ Enter Location & Dates
       └─→ Search Flights & Hotels
           └─→ Review Options

3. SELECTION
   └─→ Select Flight
       └─→ Select Hotel
           └─→ Review Summary

4. BOOKING
   └─→ Validate Selections
       └─→ Create Booking
           └─→ Generate Reference

5. CONFIRMATION
   └─→ Display Success
       └─→ Store Booking
           └─→ Return to Home

Timeline: ~5-10 minutes per booking
```

---

## 📱 Responsive Design Breakpoints

```
┌─────────────────────────────────────────────────────────────┐
│  Desktop (1200px+)                                          │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐           │
│  │   Card 1   │  │   Card 2   │  │   Card 3   │           │
│  └────────────┘  └────────────┘  └────────────┘           │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  Tablet (768px - 1199px)                                    │
│  ┌────────────┐  ┌────────────┐                            │
│  │   Card 1   │  │   Card 2   │                            │
│  └────────────┘  └────────────┘                            │
│  ┌────────────┐                                             │
│  │   Card 3   │                                             │
│  └────────────┘                                             │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  Mobile (< 768px)                                           │
│  ┌────────────┐                                             │
│  │   Card 1   │                                             │
│  └────────────┘                                             │
│  ┌────────────┐                                             │
│  │   Card 2   │                                             │
│  └────────────┘                                             │
│  ┌────────────┐                                             │
│  │   Card 3   │                                             │
│  └────────────┘                                             │
└─────────────────────────────────────────────────────────────┘
```

---

*These diagrams provide a visual understanding of the application's architecture, workflows, and data flows.*