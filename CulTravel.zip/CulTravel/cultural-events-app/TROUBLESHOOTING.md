# 🔧 Troubleshooting Guide

## PowerShell Script Execution Error

### ❌ Error Message
```
File C:\Users\Roxana\OneDrive\Documente\WindowsPowerShell\Microsoft.PowerShell_profile.ps1 
cannot be loaded because running scripts is disabled on this system.
```

### ✅ Solution: Use Command Prompt Instead

PowerShell has script execution restrictions. Use Command Prompt (cmd) instead:

---

## 🚀 EASIEST METHOD: One-Click Solution

### Option 1: Use the All-in-One Batch File

1. Open File Explorer
2. Navigate to: `Desktop\cultural-events-app`
3. **Double-click**: `INSTALL-AND-RUN.bat`
4. Wait for installation and server to start
5. Open browser to `http://localhost:3001`

This file will:
- Check you're in the right directory
- Install all dependencies
- Start the server
- Show you the URL to open

---

## 🖥️ ALTERNATIVE: Use Command Prompt (Not PowerShell)

### Step 1: Open Command Prompt

**Method A: From Start Menu**
1. Press `Windows` key
2. Type `cmd`
3. Click "Command Prompt" (NOT PowerShell)

**Method B: From File Explorer**
1. Open File Explorer
2. Navigate to `Desktop\cultural-events-app`
3. Click in the address bar
4. Type `cmd` and press Enter

### Step 2: Verify You're in the Right Place

```cmd
cd
```

Should show: `C:\Users\Roxana\Desktop\cultural-events-app`

If not, navigate there:
```cmd
cd C:\Users\Roxana\Desktop\cultural-events-app
```

### Step 3: Install Dependencies

```cmd
npm install
```

Wait for it to complete (may take 2-3 minutes first time).

### Step 4: Start the Server

```cmd
npm start
```

You should see:
```
🚀 Server running on http://localhost:3001
📊 API available at http://localhost:3001/api
🔒 Security features enabled: Helmet, CORS, Rate Limiting
```

### Step 5: Open Browser

Go to: `http://localhost:3001`

---

## 🔐 If You Want to Use PowerShell (Advanced)

If you prefer PowerShell, you need to change the execution policy:

### Option 1: Temporary (Recommended)
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Then run:
```powershell
cd C:\Users\Roxana\Desktop\cultural-events-app
npm install
npm start
```

### Option 2: Permanent (Requires Admin)
1. Right-click PowerShell
2. Select "Run as Administrator"
3. Run:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```
4. Type `Y` and press Enter

Then use PowerShell normally.

---

## 📋 Complete Command Prompt Instructions

Copy and paste these commands ONE BY ONE into Command Prompt:

```cmd
REM Navigate to the project
cd C:\Users\Roxana\Desktop\cultural-events-app

REM Verify you're in the right place
dir package.json

REM Install dependencies (first time only)
npm install

REM Start the server
npm start
```

---

## ❌ Common Errors & Solutions

### Error 1: "npm is not recognized"

**Problem**: Node.js is not installed or not in PATH

**Solution**:
1. Download Node.js from: https://nodejs.org/
2. Install it (use default options)
3. Restart Command Prompt
4. Try again

**Verify installation**:
```cmd
node --version
npm --version
```

---

### Error 2: "Cannot find module 'express'"

**Problem**: Dependencies not installed

**Solution**:
```cmd
cd C:\Users\Roxana\Desktop\cultural-events-app
npm install
```

---

### Error 3: "Port 3001 is already in use"

**Problem**: Another application is using port 3001

**Solution A**: Stop the other application

**Solution B**: Change the port
1. Open `.env` file in the cultural-events-app folder
2. Change `PORT=3001` to `PORT=3002`
3. Save the file
4. Run `npm start` again
5. Open browser to `http://localhost:3002`

---

### Error 4: "Missing script: start"

**Problem**: You're in the wrong directory

**Solution**:
```cmd
REM Check where you are
cd

REM Should show: C:\Users\Roxana\Desktop\cultural-events-app
REM If not, navigate there:
cd C:\Users\Roxana\Desktop\cultural-events-app

REM Verify package.json exists
dir package.json

REM Now try again
npm start
```

---

### Error 5: "EACCES: permission denied"

**Problem**: Permission issues

**Solution**:
1. Close Command Prompt
2. Right-click Command Prompt
3. Select "Run as Administrator"
4. Navigate to project and try again

---

## 🔍 Verification Steps

Before running the app, verify everything is correct:

### 1. Check Node.js Installation
```cmd
node --version
```
Should show: `v20.15.1` or similar

```cmd
npm --version
```
Should show: `10.7.0` or similar

### 2. Check You're in the Right Directory
```cmd
cd
```
Should show: `C:\Users\Roxana\Desktop\cultural-events-app`

### 3. Check Files Exist
```cmd
dir
```
Should show:
- package.json
- server.js
- .env
- public folder
- README.md
- etc.

### 4. Check Dependencies Installed
```cmd
dir node_modules
```
Should show many folders (express, cors, helmet, etc.)

If `node_modules` doesn't exist, run:
```cmd
npm install
```

---

## 🎯 Quick Reference

### To Install
```cmd
cd C:\Users\Roxana\Desktop\cultural-events-app
npm install
```

### To Start
```cmd
cd C:\Users\Roxana\Desktop\cultural-events-app
npm start
```

### To Stop
Press `Ctrl + C` in the terminal

### To Access
Open browser to: `http://localhost:3001`

---

## 🆘 Still Not Working?

### Check These:

1. **Are you using Command Prompt (cmd)?**
   - NOT PowerShell
   - NOT Git Bash
   - Use regular Command Prompt

2. **Are you in the right folder?**
   ```cmd
   cd
   ```
   Must show: `C:\Users\Roxana\Desktop\cultural-events-app`

3. **Does package.json exist?**
   ```cmd
   dir package.json
   ```
   Should show the file

4. **Is Node.js installed?**
   ```cmd
   node --version
   ```
   Should show version number

5. **Are dependencies installed?**
   ```cmd
   dir node_modules
   ```
   Should show folders

---

## 📞 Emergency Backup Method

If nothing else works, try this:

1. Open File Explorer
2. Go to: `C:\Users\Roxana\Desktop\cultural-events-app`
3. Hold `Shift` and right-click in empty space
4. Select "Open Command window here" or "Open PowerShell window here"
5. If PowerShell opens, type: `cmd` and press Enter
6. Now you're in Command Prompt in the right folder
7. Run: `npm install`
8. Run: `npm start`

---

## ✅ Success Indicators

You know it's working when you see:

```
🚀 Server running on http://localhost:3001
📊 API available at http://localhost:3001/api
🔒 Security features enabled: Helmet, CORS, Rate Limiting
```

And when you open `http://localhost:3001` in your browser, you see the Cultural Events Travel App with three cards: Art, History, and Tech.

---

## 📝 Summary

**Recommended Method**: Double-click `INSTALL-AND-RUN.bat`

**Manual Method**: Use Command Prompt (cmd), not PowerShell
```cmd
cd C:\Users\Roxana\Desktop\cultural-events-app
npm install
npm start
```

**Access**: `http://localhost:3001`

**Stop**: `Ctrl + C`

---

*If you're still having issues after trying all these solutions, there may be a system-specific problem. Check that Node.js is properly installed and your antivirus isn't blocking npm.*