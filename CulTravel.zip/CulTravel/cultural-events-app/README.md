# Cultural Events Travel App - Demo

A full-stack web application that helps users discover cultural events (museums, exhibitions) and book flights and accommodations.

## 🚀 Features

- **Interest-Based Discovery**: Choose from Art, History, or Tech categories
- **Event Listings**: Browse curated cultural events with detailed information
- **Flight Search**: Find available flights to event destinations
- **Hotel Search**: Discover accommodations near museums
- **Secure Booking**: Complete booking flow with authentication
- **User Authentication**: Register and login with JWT tokens
- **Security Features**: Helmet.js, CORS, rate limiting, input validation

## 🛠️ Technology Stack

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **JWT** - Authentication
- **bcryptjs** - Password hashing
- **Helmet** - Security headers
- **CORS** - Cross-origin resource sharing
- **Express Rate Limit** - API rate limiting

### Frontend
- **Vanilla JavaScript** - No framework dependencies
- **HTML5 & CSS3** - Modern responsive design
- **Fetch API** - HTTP requests

### Security Features
- JWT token-based authentication
- Password hashing with bcrypt
- Security headers (Helmet.js)
- Rate limiting (100 requests per 15 minutes)
- Input validation
- CORS protection
- XSS protection
- HTTPS ready

## 📋 Prerequisites

- Node.js (v14 or higher)
- npm (v6 or higher)

## 🔧 Installation

1. **Navigate to the project directory:**
   ```bash
   cd cultural-events-app
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Environment Setup:**
   The `.env` file is already configured with default values:
   ```
   PORT=3001
   JWT_SECRET=your-super-secret-jwt-key-change-this-in-production-12345
   NODE_ENV=development
   ```

## 🚀 Running the Application

### Start the Server

```bash
npm start
```

Or for development with auto-reload:

```bash
npm run dev
```

The server will start on `http://localhost:3001`

### Access the Application

Open your browser and navigate to:
```
http://localhost:3001
```

## 📱 Using the Application

### 1. Register/Login
- Click "Register" in the header
- Create an account with name, email, and password (min 6 characters)
- Or login if you already have an account

### 2. Select Interest
- Choose from three categories:
  - 🎨 **Art** - Paintings, sculptures, contemporary art
  - 🏛️ **History** - Ancient civilizations, historical artifacts
  - 🔬 **Tech** - AI, robotics, space exploration

### 3. Browse Events
- View curated events in your selected category
- See event details: museum, location, dates, price
- Click on any event to see full details

### 4. Plan Your Trip
- Enter your departure city (e.g., "Bucharest")
- Select departure and return dates
- Click "Find Flights & Hotels"

### 5. Select Travel Options
- Browse available flights with prices and details
- Switch to Hotels tab to see accommodation options
- Click to select your preferred flight and hotel
- Review the booking summary with total price

### 6. Complete Booking
- Click "Complete Booking"
- Receive confirmation with booking reference
- Booking is saved to your account

## 🔒 Security Features Implemented

### Authentication & Authorization
- JWT token-based authentication
- Secure password hashing (bcrypt with 10 salt rounds)
- Token expiration (24 hours)
- Protected API endpoints

### API Security
- **Helmet.js**: Sets security HTTP headers
  - Content Security Policy
  - X-Frame-Options
  - X-Content-Type-Options
  - Strict-Transport-Security
- **CORS**: Configured for localhost:3000
- **Rate Limiting**: 100 requests per 15 minutes per IP
- **Input Validation**: Server-side validation for all inputs

### Data Protection
- Passwords never stored in plain text
- JWT secrets in environment variables
- No sensitive data in client-side storage (except tokens)

## 📊 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user

### Events
- `GET /api/events/:category` - Get events by category (art/history/tech)
- `GET /api/events/detail/:id` - Get event details

### Flights
- `POST /api/flights/search` - Search flights (requires auth)

### Hotels
- `POST /api/hotels/search` - Search hotels (requires auth)

### Bookings
- `POST /api/bookings` - Create booking (requires auth)
- `GET /api/bookings` - Get user bookings (requires auth)
- `GET /api/bookings/:id` - Get booking details (requires auth)

### Health Check
- `GET /api/health` - Server health status

## 🧪 Testing the Application

### Test User Flow
1. Register a new account
2. Select "Art" interest
3. Click on "Impressionism: Masters of Light" event
4. Enter "Bucharest" as departure city
5. Click "Find Flights & Hotels"
6. Select a flight and hotel
7. Complete the booking

### Test API with cURL

**Register:**
```bash
curl -X POST http://localhost:3001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@example.com","password":"password123"}'
```

**Login:**
```bash
curl -X POST http://localhost:3001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

**Get Events:**
```bash
curl http://localhost:3001/api/events/art
```

## 📁 Project Structure

```
cultural-events-app/
├── public/
│   ├── index.html          # Main HTML file with UI
│   └── app.js              # Frontend JavaScript logic
├── server.js               # Express server with API routes
├── package.json            # Dependencies and scripts
├── .env                    # Environment variables
└── README.md              # This file
```

## 🎨 UI/UX Features

- **Responsive Design**: Works on desktop and mobile
- **Modern Gradient Background**: Purple gradient theme
- **Card-Based Layout**: Clean, organized interface
- **Smooth Animations**: Fade-in effects and hover states
- **Loading States**: Spinners for async operations
- **Modal Dialogs**: Login and register forms
- **Tab Navigation**: Switch between flights and hotels
- **Visual Feedback**: Selected items highlighted
- **Error Handling**: User-friendly error messages

## 🔄 Workflow

```mermaid
graph TD
    A[User Opens App] --> B{Authenticated?}
    B -->|No| C[Show Login/Register]
    B -->|Yes| D[Select Interest]
    C --> D
    D --> E[Browse Events]
    E --> F[Select Event]
    F --> G[Enter Travel Details]
    G --> H[Search Flights & Hotels]
    H --> I[Select Options]
    I --> J[Review Summary]
    J --> K[Complete Booking]
    K --> L[Confirmation]
```

## 🚧 Known Limitations (Demo Version)

- Mock data for events, flights, and hotels
- In-memory storage (data resets on server restart)
- No actual payment processing
- No email notifications
- No real flight/hotel API integration
- Single currency (EUR)

## 🔮 Future Enhancements

- MongoDB database integration
- Real API integrations (Amadeus, Booking.com)
- Payment processing (Stripe)
- Email notifications
- User profile management
- Booking history
- Reviews and ratings
- Social sharing
- Multi-language support
- Mobile app (React Native)

## 🐛 Troubleshooting

### Port Already in Use
If port 3001 is already in use, change it in `.env`:
```
PORT=3002
```

### CORS Errors
Make sure the frontend is accessing `http://localhost:3001` and not a different port.

### Authentication Issues
Clear browser localStorage and try again:
```javascript
localStorage.clear()
```

### Server Won't Start
Make sure all dependencies are installed:
```bash
npm install
```

## 📝 License

MIT License - Feel free to use this demo for learning purposes.

## 👨‍💻 Author

Created as a demonstration of full-stack web development with security best practices.

## 🙏 Acknowledgments

- Event images from Unsplash
- Icons from Unicode emoji
- Inspired by modern travel booking platforms