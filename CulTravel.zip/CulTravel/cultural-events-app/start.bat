@echo off
echo Starting Cultural Events Travel App...
echo.
echo Server will be available at: http://localhost:3001
echo.
node server.js

@REM Made with Bob
