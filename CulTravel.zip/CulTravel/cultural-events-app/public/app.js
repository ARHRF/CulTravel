// API Configuration
const API_URL = 'http://localhost:3001/api';

// State Management
let currentUser = null;
let currentInterest = null;
let currentEvent = null;
let selectedFlight = null;
let selectedHotel = null;
let events = [];

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    setDefaultDates();
});

// Authentication Functions
function checkAuth() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    
    if (token && user) {
        currentUser = JSON.parse(user);
        updateAuthUI();
    }
}

function updateAuthUI() {
    const authButtons = document.getElementById('authButtons');
    const userInfo = document.getElementById('userInfo');
    const userName = document.getElementById('userName');
    const userAvatar = document.getElementById('userAvatar');
    
    if (currentUser) {
        authButtons.classList.add('hidden');
        userInfo.classList.remove('hidden');
        userName.textContent = currentUser.name;
        userAvatar.textContent = currentUser.name.charAt(0).toUpperCase();
    } else {
        authButtons.classList.remove('hidden');
        userInfo.classList.add('hidden');
    }
}

async function register(event) {
    event.preventDefault();
    
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    
    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            currentUser = data.user;
            updateAuthUI();
            closeModal('registerModal');
            showAlert('registerAlert', 'Registration successful!', 'success');
        } else {
            showAlert('registerAlert', data.error || 'Registration failed', 'error');
        }
    } catch (error) {
        showAlert('registerAlert', 'Network error. Please try again.', 'error');
    }
}

async function login(event) {
    event.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            currentUser = data.user;
            updateAuthUI();
            closeModal('loginModal');
            showAlert('loginAlert', 'Login successful!', 'success');
        } else {
            showAlert('loginAlert', data.error || 'Login failed', 'error');
        }
    } catch (error) {
        showAlert('loginAlert', 'Network error. Please try again.', 'error');
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    currentUser = null;
    updateAuthUI();
    showScreen('interestScreen');
}

// Modal Functions
function showLoginModal() {
    document.getElementById('loginModal').classList.add('active');
}

function showRegisterModal() {
    document.getElementById('registerModal').classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

function showAlert(elementId, message, type) {
    const alertDiv = document.getElementById(elementId);
    alertDiv.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    setTimeout(() => {
        alertDiv.innerHTML = '';
    }, 5000);
}

// Screen Navigation
function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    document.getElementById(screenId).classList.add('active');
}

// Interest Selection
async function selectInterest(interest) {
    currentInterest = interest;
    showScreen('eventsScreen');
    
    const titles = {
        art: '🎨 Art Exhibitions',
        history: '🏛️ History Exhibitions',
        tech: '🔬 Technology Exhibitions'
    };
    
    document.getElementById('eventsTitle').textContent = titles[interest];
    
    await loadEvents(interest);
}

async function loadEvents(category) {
    const eventsGrid = document.getElementById('eventsGrid');
    eventsGrid.innerHTML = '<div class="loading"><div class="spinner"></div><p>Loading events...</p></div>';
    
    try {
        const response = await fetch(`${API_URL}/events/${category}`);
        const data = await response.json();
        events = data.events;
        
        eventsGrid.innerHTML = '';
        
        events.forEach(event => {
            const eventCard = createEventCard(event);
            eventsGrid.appendChild(eventCard);
        });
    } catch (error) {
        eventsGrid.innerHTML = '<p style="text-align: center; color: var(--danger-color);">Failed to load events. Please try again.</p>';
    }
}

function createEventCard(event) {
    const card = document.createElement('div');
    card.className = 'event-card';
    card.onclick = () => showEventDetail(event);
    
    const startDate = new Date(event.dates.start).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const endDate = new Date(event.dates.end).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    
    card.innerHTML = `
        <img src="${event.image}" alt="${event.title}" class="event-image">
        <div class="event-content">
            <h3 class="event-title">${event.title}</h3>
            <p class="event-museum">📍 ${event.museum}</p>
            <p class="event-location">${event.location.city}, ${event.location.country}</p>
            <p class="event-dates">📅 ${startDate} - ${endDate}</p>
            <p class="event-price">€${event.price}</p>
        </div>
    `;
    
    return card;
}

function showEventDetail(event) {
    currentEvent = event;
    showScreen('eventDetailScreen');
    
    document.getElementById('detailImage').src = event.image;
    document.getElementById('detailTitle').textContent = event.title;
    document.getElementById('detailMuseum').textContent = `📍 ${event.museum}`;
    document.getElementById('detailLocation').textContent = `${event.location.city}, ${event.location.country}`;
    
    const startDate = new Date(event.dates.start).toLocaleDateString('en-US', { month: 'long', day: 'numeric' });
    const endDate = new Date(event.dates.end).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    document.getElementById('detailDates').textContent = `📅 ${startDate} - ${endDate}`;
    
    document.getElementById('detailDescription').textContent = event.description;
    document.getElementById('detailPrice').textContent = event.price;
}

function backToEvents() {
    showScreen('eventsScreen');
}

function setDefaultDates() {
    const today = new Date();
    const departure = new Date(today);
    departure.setDate(today.getDate() + 7);
    
    const returnDate = new Date(departure);
    returnDate.setDate(departure.getDate() + 3);
    
    document.getElementById('departureDate').value = departure.toISOString().split('T')[0];
    document.getElementById('returnDate').value = returnDate.toISOString().split('T')[0];
}

// Travel Search
async function searchTravel() {
    if (!currentUser) {
        alert('Please login to search for flights and hotels');
        showLoginModal();
        return;
    }
    
    const userLocation = document.getElementById('userLocation').value;
    const departureDate = document.getElementById('departureDate').value;
    const returnDate = document.getElementById('returnDate').value;
    
    if (!userLocation || !departureDate || !returnDate) {
        alert('Please fill in all travel details');
        return;
    }
    
    showScreen('searchResultsScreen');
    
    await Promise.all([
        loadFlights(userLocation, departureDate, returnDate),
        loadHotels(departureDate, returnDate)
    ]);
}

async function loadFlights(origin, departureDate, returnDate) {
    const flightsGrid = document.getElementById('flightsGrid');
    flightsGrid.innerHTML = '<div class="loading"><div class="spinner"></div><p>Searching flights...</p></div>';
    
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/flights/search`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                origin,
                destination: currentEvent.location.city,
                departureDate,
                returnDate
            })
        });
        
        const data = await response.json();
        
        flightsGrid.innerHTML = '';
        
        data.flights.forEach(flight => {
            const flightCard = createFlightCard(flight);
            flightsGrid.appendChild(flightCard);
        });
    } catch (error) {
        flightsGrid.innerHTML = '<p style="text-align: center; color: var(--danger-color);">Failed to load flights. Please try again.</p>';
    }
}

function createFlightCard(flight) {
    const card = document.createElement('div');
    card.className = 'result-card';
    card.onclick = () => selectFlight(flight, card);
    
    card.innerHTML = `
        <div class="result-info">
            <h4>✈️ ${flight.airline}</h4>
            <p class="result-details">
                ${flight.departure} → ${flight.arrival} | ${flight.duration} | ${flight.stops === 0 ? 'Direct' : flight.stops + ' stop(s)'}
            </p>
        </div>
        <div class="result-price">€${flight.price}</div>
    `;
    
    return card;
}

function selectFlight(flight, cardElement) {
    // Remove previous selection
    document.querySelectorAll('#flightsGrid .result-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    cardElement.classList.add('selected');
    selectedFlight = flight;
    updateBookingSummary();
}

async function loadHotels(checkIn, checkOut) {
    const hotelsGrid = document.getElementById('hotelsGrid');
    hotelsGrid.innerHTML = '<div class="loading"><div class="spinner"></div><p>Searching hotels...</p></div>';
    
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/hotels/search`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                location: currentEvent.location,
                checkIn,
                checkOut,
                guests: 1
            })
        });
        
        const data = await response.json();
        
        hotelsGrid.innerHTML = '';
        
        data.hotels.forEach(hotel => {
            const hotelCard = createHotelCard(hotel, checkIn, checkOut);
            hotelsGrid.appendChild(hotelCard);
        });
    } catch (error) {
        hotelsGrid.innerHTML = '<p style="text-align: center; color: var(--danger-color);">Failed to load hotels. Please try again.</p>';
    }
}

function createHotelCard(hotel, checkIn, checkOut) {
    const card = document.createElement('div');
    card.className = 'result-card hotel-card';
    card.onclick = () => selectHotel(hotel, card, checkIn, checkOut);
    
    const nights = Math.ceil((new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24));
    const totalPrice = hotel.price * nights;
    
    card.innerHTML = `
        <img src="${hotel.image}" alt="${hotel.name}" class="hotel-image">
        <div class="result-info">
            <h4>🏨 ${hotel.name}</h4>
            <p class="result-details">
                ⭐ ${hotel.rating} | 📍 ${hotel.distance} from museum<br>
                ${hotel.amenities.join(' • ')}
            </p>
        </div>
        <div>
            <div class="result-price">€${totalPrice}</div>
            <p style="font-size: 12px; color: var(--gray);">€${hotel.price}/night × ${nights} nights</p>
        </div>
    `;
    
    return card;
}

function selectHotel(hotel, cardElement, checkIn, checkOut) {
    // Remove previous selection
    document.querySelectorAll('#hotelsGrid .result-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    cardElement.classList.add('selected');
    
    const nights = Math.ceil((new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24));
    selectedHotel = {
        ...hotel,
        nights,
        totalPrice: hotel.price * nights
    };
    
    updateBookingSummary();
}

function showTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Show/hide tab content
    document.getElementById('flightsTab').classList.toggle('hidden', tabName !== 'flights');
    document.getElementById('hotelsTab').classList.toggle('hidden', tabName !== 'hotels');
}

function updateBookingSummary() {
    const flightInfo = selectedFlight ? `${selectedFlight.airline} - €${selectedFlight.price}` : 'None';
    const hotelInfo = selectedHotel ? `${selectedHotel.name} - €${selectedHotel.totalPrice}` : 'None';
    
    document.getElementById('selectedFlightInfo').textContent = flightInfo;
    document.getElementById('selectedHotelInfo').textContent = hotelInfo;
    document.getElementById('selectedEventPrice').textContent = `€${currentEvent.price}`;
    
    const total = (selectedFlight?.price || 0) + (selectedHotel?.totalPrice || 0) + currentEvent.price;
    document.getElementById('totalPrice').textContent = `€${total}`;
}

async function completeBooking() {
    if (!currentUser) {
        alert('Please login to complete booking');
        showLoginModal();
        return;
    }
    
    if (!selectedFlight || !selectedHotel) {
        alert('Please select both a flight and a hotel');
        return;
    }
    
    const total = selectedFlight.price + selectedHotel.totalPrice + currentEvent.price;
    
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/bookings`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                eventId: currentEvent.id,
                flightId: selectedFlight.id,
                hotelId: selectedHotel.id,
                totalAmount: total
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            alert(`🎉 Booking Confirmed!\n\nBooking Reference: ${data.booking.bookingReference}\n\nTotal Amount: €${total}\n\nYou will receive a confirmation email shortly.`);
            
            // Reset selections
            selectedFlight = null;
            selectedHotel = null;
            
            // Go back to interests
            showScreen('interestScreen');
        } else {
            alert('Booking failed: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        alert('Network error. Please try again.');
    }
}

// Close modals when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.classList.remove('active');
    }
}

// Made with Bob
